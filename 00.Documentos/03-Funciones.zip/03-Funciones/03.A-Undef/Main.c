#include <stdio.h>
#include "header1.h"

#undef TRUE

#define TRUE 1

int main(void) {
    char a = TRUE;
    printf("Run test \r\n");
    if (a == TRUE) {
        printf("True %d", a);
    } else if (a == FALSE) {
        printf("False %d", a);
    } else {
        printf("Unsuspected value for a: %d", a);
    }
}