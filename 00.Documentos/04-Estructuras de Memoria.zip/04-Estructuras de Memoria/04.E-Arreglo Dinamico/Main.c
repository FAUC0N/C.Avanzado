#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE 10

//#define USE_MALLOC
//#define USE_CALLOC
#define USE_STATIC


int* CreateArray(int n){
    //int* result;
    //printf("Allocating %d bytes\r\n", n);
    #ifdef USE_MALLOC
        result = (int*)malloc(n * sizeof(int));
    #else 
        #ifdef USE_CALLOC
            result = (int*)calloc(n, sizeof(int));
        #else
            static int result[ARRAY_SIZE];
        #endif
    #endif
    
    return result;
}

void FillArray(int array[], int size) {
    int i;
    for (i=0; i<size; i++) {
        array[i] = i + 1;
    }
}

void DisplayArray(int array[], int size) {
    int i;
    for (i=0; i<size; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", array[i]);
    }
    printf("\r\n");
}

int main(void) {
    int *dynamicArray;

    printf("-------------------------------------\r\n");
    printf("Allocating %d integer array\r\n", ARRAY_SIZE);
    // Create the array
    dynamicArray = CreateArray(ARRAY_SIZE);
    if (dynamicArray != NULL) {
        // Display the array
        printf("Display the array content as it is created\r\n");
        DisplayArray(dynamicArray, ARRAY_SIZE);
        printf("Array size: %d\r\n", sizeof(dynamicArray));
        // Fill array
        printf("Set array data\r\n");
        FillArray(dynamicArray, ARRAY_SIZE);
        // Display again
        printf("Display the array content after it is initialized\r\n");
        DisplayArray(dynamicArray, ARRAY_SIZE);
        // Relase memory
        free(dynamicArray);
    } else {
        printf("Memory could not be allocated\r\n");
    }
    return 0;
}