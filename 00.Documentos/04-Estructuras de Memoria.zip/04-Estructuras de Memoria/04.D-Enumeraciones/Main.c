#include <stdio.h>

enum Days {Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday};

int main(void) {
    enum Days day1 = Sunday;
    enum Days day2 = Wednesday;
    unsigned char test = Sunday;
 
    printf("Sunday = %d\r\n", day1);
    printf("Wednesday - Sunday = %d\r\n", day2 - day1);
    printf("Size of the enum value = %d\r\n", sizeof(day1));
    printf("Size of the enum type = %d\r\n", sizeof(enum Days));
}