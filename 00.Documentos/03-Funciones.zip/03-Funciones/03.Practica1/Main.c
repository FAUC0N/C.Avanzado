#include <stdio.h>

void Fibonacci(int count);

int main(void) {
    printf("---------------------------\r\n");
    Fibonacci(10);
    return 0;
}

void Fibonacci(int count) {
    int a, b, f;
    int i;
    a = 1;
    b = 0;
    printf("Fibonacci series\r\n");
    for (i=0; i < count; i++) {
        f = a + b;
        printf("%d\r\n", f);
        a = b;
        b = f;
    }
}