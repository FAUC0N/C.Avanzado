#include <stdio.h>

void MyFunction(void) {
    int localA;
    int localB;
    int localC;
    printf("A = %d, B = %d, C = %d\r\n", localA, localB, localC);
    localA = 3;
    localC = localA + localB;
    printf("A = %d, B = %d, C = %d\r\n", localA, localB, localC);
}

int main(void) {
    int localA = 4;
    int localB = 5;
    int localC;

    printf("A = %d, B = %d, C = %d\r\n", localA, localB, localC);
    localC = localA + localB;
    printf("A = %d, B = %d, C = %d\r\n", localA, localB, localC);
    MyFunction();
    printf("A = %d, B = %d, C = %d\r\n", localA, localB, localC);
} 