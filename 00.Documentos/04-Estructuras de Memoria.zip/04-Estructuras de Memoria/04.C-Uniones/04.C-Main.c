#include <stdio.h>
#include <string.h>

union record {
    int A;
    int B;
    char N[10];
};

typedef union record structType;

int main(void) {
    union record a;
    union record b;
    structType c;
    printf("--------------------\r\n");
    printf("Assign and display the members of a\r\n");
    printf("A: %d, B: %d, N:%s\r\n", a.A, a.B, a.N);
    a.A=1;
    printf("A: %d, B: %d, N:%s\r\n", a.A, a.B, a.N);
    a.B=4;
    printf("A: %d, B: %d, N:%s\r\n", a.A, a.B, a.N);
    strcpy(a.N,"One");
    printf("A: %d, B: %d, N:%s\r\n", a.A, a.B, a.N);
    printf("Assign and display the members of b\r\n");
    printf("A: %d, B: %d, N:%s\r\n", b.A, b.B, b.N);
    b.A=5;
    printf("A: %d, B: %d, N:%s\r\n", b.A, b.B, b.N);
    b.B=3;
    printf("A: %d, B: %d, N:%s\r\n", b.A, b.B, b.N);
    strcpy(b.N,"Two");
    printf("A: %d, B: %d, N:%s\r\n", b.A, b.B, b.N);

    return 0;
}