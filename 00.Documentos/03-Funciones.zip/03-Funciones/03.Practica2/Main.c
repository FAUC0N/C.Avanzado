#include <stdio.h>
#include <Math.h>

#define PI 3.14159265358979
#define DEGREE_TO_RADIANS(G) G*PI/180
//#define USE_MACROS

#ifdef USE_MACROS
    #define CircleArea(R) PI * pow(R, 2)
    #define SquareArea(S) pow(S, 2)
    #define PentagonArea(S,N) N * S * ((S/2) / tan(DEGREE_TO_RADIANS(360.0/N/2))) /2
#else
    float CircleArea(float radius) {
        float result;
        result = PI * pow(radius, 2);
        return result;
    }
    float SquareArea(float side) {
        float result;
        result = pow(side, 2);
        return result;
    }
    float PentagonArea(float side) {
        float result;
        float AP;
        float angle = 360.0 / 5 / 2;
        // Calculate AP
        AP = (side/2) / tan(DEGREE_TO_RADIANS(angle));
        result = 5.0 * side * AP /2;
        return result;
    }
#endif

int main(void) {
    float area;

    printf("------------------------\r\n");
    // The circle area
    area = CircleArea(4);
    printf("Circle area = %f\r\n", area);
    area = SquareArea(4);
    printf("Square area = %f\r\n", area);
    area = PentagonArea(4);
    printf("Pentagon area = %f\r\n", area);

}