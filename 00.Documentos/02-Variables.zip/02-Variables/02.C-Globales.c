#include <stdio.h>
#include "02.C-Library.h"

int VariableD;

int main(void) {
    int localA = 4;
    int localB = 5;
    int localC;

    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
    localC = localA + localB + VariableD;
    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
    MyFunction();
    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
    localC = localA + localB + VariableD;
} 