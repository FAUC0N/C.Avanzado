#include <stdio.h>

#define ARRAY_SIZE 10

int main(void) {
    int arrayA[ARRAY_SIZE];
    int arrayB[ARRAY_SIZE];
    float arrayMultiplication[ARRAY_SIZE];
    int i;
    printf("---------------------------------------------\r\n");
    printf("Address of arrayA: %d\r\n", arrayA);
    printf("Address of arrayB: %d\r\n", arrayB);
    printf("Address of arrayMultiplication: %d\r\n", arrayMultiplication);
    for (i=0; i < ARRAY_SIZE; i++) {
        arrayA[i] = (i + 1);
        arrayB[i] = (i + 1) * 2;
        arrayMultiplication[i] = arrayA[i] * arrayB[i];
    }
    printf("Array multiplication\r\n");
    for (i=0; i < ARRAY_SIZE; i++) {
        printf("%d * %d = %f\r\n", arrayA[i], arrayB[i], arrayMultiplication[i]);
    }
    printf("Integer array values\r\n");
    for (i=0; i < ARRAY_SIZE + 5; i++) {
        printf("%d\r\n", arrayB[i] );
    }
    printf("Integer array addreses by pointer\r\n");
    for (i=0; i < ARRAY_SIZE + 5; i++) {
        printf("%d\r\n", (arrayB + i) );
    }    
    printf("Integer array value by pointer\r\n");
    for (i=0; i < ARRAY_SIZE + 5; i++) {
        printf("%d\r\n", *(arrayB + i) );
    }    

    return 0;
}