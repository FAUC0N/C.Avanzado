#include <stdio.h>
int VariableD;

void MyFunction(void) {
    int localA;
    int localB;
    int localC;
    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
    localA = 3;
    localC = localA + localB;
    VariableD = 7;
    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
    localC = localA + localB + VariableD;
    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
}

int main(void) {
    int localA = 4;
    int localB = 5;
    int localC;

    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
    localC = localA + localB + VariableD;
    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
    MyFunction();
    printf("A = %d, B = %d, C = %d D = %d\r\n", localA, localB, localC, VariableD);
    localC = localA + localB + VariableD;
} 