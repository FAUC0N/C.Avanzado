#include <stdio.h>

int main(void) {
    printf("It works!");
    return 0;
}