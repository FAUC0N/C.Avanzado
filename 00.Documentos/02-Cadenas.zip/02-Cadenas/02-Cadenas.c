#include <string.h>
#include <stdio.h>

int main(void) {
    char text[50];

    printf("%s", text);
    strcpy(text, "Hola!");
    printf("%s", text);
    strcat(text, " Ya estamos por terminar!");
    printf("%s", text);
    strcat(text, "\r\n");
    printf("%s", text);
    printf("Tenemos %d caracteres en la cadena '%s'", strlen(text), text);
    return 0;
}