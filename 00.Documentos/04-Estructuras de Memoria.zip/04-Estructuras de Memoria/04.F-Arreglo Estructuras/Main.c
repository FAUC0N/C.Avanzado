#include <stdio.h>
#include <stdlib.h>

#define RECORD_COUNT 10
//#define USE_MALLOC

struct Record {
    int Age;
    int ID;
    char Name[20];
};
typedef struct Record Person;

Person* CreateList(int n){
    Person* result;
    int i;
    printf("Allocating %d records\r\n", n);
    #ifdef USE_MALLOC
        result = (Person*)malloc(RECORD_COUNT * sizeof(Person));
        if (result != NULL) {
            printf("Array size: %d\r\n", sizeof(result));
        }
    #else 
        result = (Person*)calloc(n, sizeof(Person));
        if (result != NULL) {
            printf("Array size: %d\r\n", sizeof(result));
        }
    #endif
    // Initialize array
    for (i=0; i< n; i++) {
        result[i].ID = rand();
        result[i].Age = rand();
        sprintf(result[i].Name, "Juan %d", i); 
    }
    return result;
}

void DisplayList(Person list[], int n) {
    int i;

    for (i=0;i<n;i++) {
        printf("ID: %d\tName: %s\tAge: %d\r\n", list[i].ID, list[i].Name, list[i].Age);
    }
}

int main(void) {
    Person *list;
    printf("-------------------------------------\r\n");
    printf("Size of Person: %d\r\n", sizeof(Person));
    // Create the array
    list = CreateList(RECORD_COUNT);

    printf("Allocating %d records\r\n", RECORD_COUNT);
    printf("Printing the list content\r\n");
    DisplayList(list, RECORD_COUNT);
    free(list);
    return 0;
}